file_bucket = "s3://rawdata/"
temp_s3_bucket = "s3://rawdata/temp_bucket"

schema = "prod"
dbname = "prd_rdshift"
port = "5439"
user = "admin"
password = "admin123"
table_name = "s3_to_redshift"

host_url = "jdbc:redshift://endpointname:5439/prd_rdshift"

aws_access_key_id = "SFDASFSFGSDFGSDFGSDGSF"
aws_secret_access_key = "ssgfsfsdwttSDF/DGDFHTG/jhkjhjJHKJHjhHKJH"
incremental_load = "Y"
